import { PDFDocument } from 'pdf-lib';
import { downloadContentFromMessage } from '@rexxhayanasi/elaina-baileys';
import { sendFakeQuoted } from '../../lib/fakequoted.js';

export default {
    command: ['topdf', 'img2pdf', 'pdf'],
    category: 'tools',
    execute: async (denn, m, { prefix, command }) => {
        const isQuoted = !!m.quoted;
        const msg = isQuoted ? (m.quoted.msg || m.quoted) : m.msg;
        const mtype = isQuoted ? m.quoted.mtype : m.mtype;

        let mediaMime = msg?.mimetype || '';
        if (!mediaMime && mtype === 'imageMessage') mediaMime = 'image/jpeg';

        if (!/image/.test(mediaMime)) {
            return sendFakeQuoted(denn, m, 
                `📄 *IMAGE TO PDF*\n\n` +
                `*Format:* Kirim/reply gambar dengan caption *${prefix + command}*\n` +
                `*Contoh:* Reply gambar, lalu ketik \`${prefix}${command}\``,
                { title: 'Image to PDF', body: 'Kirim atau reply gambar yang ingin dijadikan PDF' }
            );
        }

        const wait = await sendFakeQuoted(denn, m, global.msg?.wait || '⏳ Mengonversi gambar ke PDF...', {
            title: 'Image to PDF', body: 'Memproses...'
        }).catch(() => null);

        try {
            const stream = await downloadContentFromMessage(msg, 'image');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            if (!buffer || buffer.length < 100) {
                throw new Error('Gagal mengunduh gambar atau buffer kosong.');
            }

            const pdfDoc = await PDFDocument.create();
            
            let image;
            if (mediaMime.includes('png')) {
                image = await pdfDoc.embedPng(buffer);
            } else {
                image = await pdfDoc.embedJpg(buffer);
            }

            const page = pdfDoc.addPage([image.width, image.height]);
            page.drawImage(image, {
                x: 0,
                y: 0,
                width: image.width,
                height: image.height,
            });

            const pdfBytes = await pdfDoc.save();
            const pdfBuffer = Buffer.from(pdfBytes);
            if (wait?.key?.id) {
                try { await denn.sendMessage(m.chat, { delete: wait.key }); } catch (_) {}
            }

            await denn.sendMessage(m.chat, {
                document: pdfBuffer,
                fileName: `patrickmd_${Date.now()}.pdf`,
                mimetype: 'application/pdf',
                caption: `✅ *BERHASIL DIKONVERSI*\n\n📄 File PDF siap diunduh.`
            }, { quoted: m });

        } catch (e) {
            if (wait?.key?.id) {
                try { await denn.sendMessage(m.chat, { delete: wait.key }); } catch (_) {}
            }
            console.error('[Topdf Error]', e.message);
            sendFakeQuoted(denn, m, `❌ Gagal mengonversi ke PDF:\n${e.message}`, {
                title: 'Topdf Gagal', body: 'Terjadi kesalahan saat memproses gambar'
            });
        }
    }
};